import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-buy-products-header',
  templateUrl: './buy-products-header.component.html',
  styleUrls: ['./buy-products-header.component.scss']
})
export class BuyProductsHeaderComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
