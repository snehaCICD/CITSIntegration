import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-upload-products',
  templateUrl: './upload-products.component.html',
  styleUrls: ['./upload-products.component.scss']
})
export class UploadProductsComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
