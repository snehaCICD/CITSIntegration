import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-upload-products-list',
  templateUrl: './upload-products-list.component.html',
  styleUrls: ['./upload-products-list.component.scss']
})
export class UploadProductsListComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
