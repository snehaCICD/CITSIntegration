import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-sell-products',
  templateUrl: './sell-products.component.html',
  styleUrls: ['./sell-products.component.css']
})
export class SellProductsComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
